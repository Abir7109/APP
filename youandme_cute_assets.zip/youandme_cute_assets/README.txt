YOU&ME — Cute asset pack
========================
Soft-clay kawaii illustration set, keyed to the YOU&ME brand palette.

Contents
--------
illustrations/        12 transparent PNGs (the app's illustration set)
  mascots.png          720 x 408   the pair (pink heart + lilac bun) holding hands
  splash_art.png       647 x 720   the pair on a cloud (tall, for splash/onboarding)
  empty_state.png      520 x 352   the pair peeking into an empty box (reusable)
  pattern_hearts.png   512 x 512   seamless scatter tile, transparent, 6 KB
  spot_bucket.png      391 x 420   suitcase + map + location pin
  spot_checkin.png     420 x 335   smiling sun behind a cloud
  spot_capsule.png     420 x 314   sealed envelope + clock
  spot_coupons.png     420 x 407   two scalloped tickets
  spot_goals.png       312 x 420   savings jar with hearts + sprout
  spot_photo.png       362 x 420   instant camera with photo
  spot_deeptalk.png    420 x 343   two speech bubbles
  spot_chores.png      371 x 420   broom + dustpan + sparkles

brand/
  heart_icon.png       384 x 320   brand mark (transparent, floats on any surface)
  notification_icon.png   96 x 96   white silhouette on transparency (status bar / FCM)

app_icon/
  app_icon_1024.png   1024 x 1024  master launcher artwork (full bleed, no rounded corners)

platform-icons/
  android/            48 / 72 / 96 / 144 / 192 px  (mipmap densities)
  ios/                every AppIcon.appiconset size, 20 px -> 1024 px
  web/                192 / 512 / maskable 192+512 / favicon 32
  android_drawable/   ic_stat_heart.png for Firebase Cloud Messaging

preview/
  asset_sheet.png     contact sheet of the whole set + palette

Usage rules (from docs/UI_REDESIGN.md)
--------------------------------------
1. Every illustration sits on a soft-pink tile (#FFF0FB). Never float art on
   white, never on a gradient.
2. Sizes: 52-64 px in cards/list rows, 88-112 px in headers, 150-180 px in
   empty states, 220-280 px on splash. 3x screens: use these at their natural
   size (the art is already 3x-ready).
3. One illustration per screen, one per card. Never stretch: BoxFit.contain.
4. Art never carries text or data. Numbers and labels stay in the type system.
5. Decorative art should be excluded from the semantics tree; give a short
   semantic label only when the picture is the message.
6. Dark mode: put art on the dark soft-pink tile (#3E2436) and cap opacity at
   ~0.92. Shadows are disabled in dark mode.
7. pattern_hearts.png is a seamless tile: use ImageRepeat.repeat at 6-8%
   opacity as a backdrop, never as a foreground illustration.

Palette
-------
primary    #FF4576    tint      #FF7B83    peach    #FFB199
lilac      #C9A7FF    soft pink #FFF0FB    cream    #FFF7FA
plum text  #3E0554

Regenerating / extending
------------------------
These were produced from one style recipe. Append this to any new prompt:

  Kawaii sticker illustration in a soft 3D clay / matte felt style: chunky
  rounded shapes, gentle gradients, subtle inner glow, no hard outlines.
  Palette strictly blush pink #FF4576, coral #FF7B83, peach #FFB199, lilac
  #C9A7FF, cream #FFF7FA, deep plum accents #3E0554. Single centered subject
  with generous empty margin, nothing touches the edges. Perfectly flat
  uniform solid background of exactly #FFF0FB, no gradient, no vignette, no
  cast shadow on the background, no texture in the background. No text, no
  letters, no numbers, no logo, no watermark, no frame.

Post-processing used here: flood-fill the flat background from the borders
(tolerance ~10 RGB) to alpha 0, blur the alpha 0.7 px for soft edges, trim to
content with 4% padding, resize the longest edge to 420 px (spots) or 720 px
(scenes), export PNG RGBA.

Notes
-----
- Mascots are original to YOU&ME (a heart and a bun). They are not modelled on
  any other app's characters. Treat the set as your own brand IP.
- In the Flutter project these files live in assets/illustrations and
  assets/brand, declared in pubspec.yaml, and are addressed in code through
  lib/core/widgets/app_illustration.dart (enum AppArt).
